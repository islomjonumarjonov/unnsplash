import React from "react";

function Contact() {
  return (
    <div>
      <h1>Contact</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. At nisi,
        aliquid optio tempore nemo, maxime, consequatur modi quas quisquam
        molestiae quae praesentium deserunt. Cum, minus quas. Minima animi ea
        illum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet
        dolorum molestiae quibusdam sunt quo quod ea ipsa repudiandae deserunt
        dolore numquam, hic similique. Ipsam explicabo quos doloribus eum saepe,
        officia atque harum voluptates consequuntur laborum ratione facilis
        placeat voluptatibus nisi ea molestiae quis dolores eveniet
        perspiciatis. Harum, ratione? Facilis a ratione praesentium impedit aut
        harum ex temporibus. Sed natus eos, accusantium ratione eaque voluptatem
        tempore asperiores nesciunt cum harum beatae, suscipit neque, et
        tenetur! Harum accusantium labore hic est praesentium corporis esse!
        Amet, numquam nobis sunt accusamus impedit qui, est quasi sint,
        excepturi ratione quod sapiente ipsa quo corrupti.
      </p>
    </div>
  );
}

export default Contact;
