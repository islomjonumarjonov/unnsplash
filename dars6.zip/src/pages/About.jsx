import React from "react";

function About() {
  return (
    <div>
      <h1>About</h1>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores optio
        nulla cum quis dolore porro eaque ullam laborum aperiam blanditiis.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt
        inventore libero, reprehenderit fugiat est quam molestias ex earum omnis
        ab vel sunt architecto eligendi temporibus aliquam consectetur tempore
        quos, aspernatur quo sit porro repudiandae. Quasi et repellendus
        obcaecati tempora iure! Voluptatibus a quaerat consectetur assumenda
        sunt et est ad expedita.
      </p>
    </div>
  );
}

export default About;
